/**
 * Tab Time - Local Storage & IndexedDB Module
 * 100% Client-Side Persistence with Zero Cloud Telemetry
 */

const DB_NAME = 'TabTimeDB';
const DB_VERSION = 1;
const STORE_SESSIONS = 'sessions';
const STORE_SUMMARIES = 'daily_summaries';

export class TabTimeStorage {
  constructor() {
    this.db = null;
  }

  async initDB() {
    if (this.db) return this.db;
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = event.target.result;

        // Raw Session Store
        if (!db.objectStoreNames.contains(STORE_SESSIONS)) {
          const sessionStore = db.createObjectStore(STORE_SESSIONS, { keyPath: 'id', autoIncrement: true });
          sessionStore.createIndex('domain', 'domain', { unique: false });
          sessionStore.createIndex('date', 'date', { unique: false });
          sessionStore.createIndex('category', 'category', { unique: false });
        }

        // Daily Summary Rollups Store
        if (!db.objectStoreNames.contains(STORE_SUMMARIES)) {
          const summaryStore = db.createObjectStore(STORE_SUMMARIES, { keyPath: 'date' });
        }
      };

      request.onsuccess = (event) => {
        this.db = event.target.result;
        resolve(this.db);
      };

      request.onerror = (event) => {
        console.error('IndexedDB open error:', event.target.error);
        reject(event.target.error);
      };
    });
  }

  async recordSession(sessionData) {
    await this.initDB();
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([STORE_SESSIONS], 'readwrite');
      const store = transaction.objectStore(STORE_SESSIONS);
      const request = store.add(sessionData);

      request.onsuccess = () => resolve(request.result);
      request.onerror = (e) => reject(e.target.error);
    });
  }

  async getSessionsByDate(dateStr) {
    await this.initDB();
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([STORE_SESSIONS], 'readonly');
      const store = transaction.objectStore(STORE_SESSIONS);
      const index = store.index('date');
      const request = index.getAll(IDBKeyRange.only(dateStr));

      request.onsuccess = () => resolve(request.result || []);
      request.onerror = (e) => reject(e.target.error);
    });
  }

  async getAllSessions() {
    await this.initDB();
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([STORE_SESSIONS], 'readonly');
      const store = transaction.objectStore(STORE_SESSIONS);
      const request = store.getAll();

      request.onsuccess = () => resolve(request.result || []);
      request.onerror = (e) => reject(e.target.error);
    });
  }

  async clearAllData() {
    await this.initDB();
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([STORE_SESSIONS, STORE_SUMMARIES], 'readwrite');
      transaction.objectStore(STORE_SESSIONS).clear();
      transaction.objectStore(STORE_SUMMARIES).clear();
      transaction.oncomplete = () => resolve(true);
      transaction.onerror = (e) => reject(e.target.error);
    });
  }
}

// Default domain categorization rules
export const DEFAULT_CATEGORY_RULES = {
  // Productive
  'github.com': 'Productive',
  'gitlab.com': 'Productive',
  'stackoverflow.com': 'Productive',
  'docs.google.com': 'Productive',
  'notion.so': 'Productive',
  'slack.com': 'Productive',
  'trello.com': 'Productive',
  'figma.com': 'Productive',
  'codepen.io': 'Productive',
  'chatgpt.com': 'Productive',
  
  // Educational
  'sciencedirect.com': 'Educational',
  'ieeexplore.ieee.org': 'Educational',
  'acm.org': 'Educational',
  'researchgate.net': 'Educational',
  'jstor.org': 'Educational',
  'yorksj.ac.uk': 'Educational',
  'moodle.org': 'Educational',
  'khanacademy.org': 'Educational',
  'coursera.org': 'Educational',
  'edx.org': 'Educational',
  'wikipedia.org': 'Educational',

  // Social
  'twitter.com': 'Social',
  'x.com': 'Social',
  'facebook.com': 'Social',
  'instagram.com': 'Social',
  'reddit.com': 'Social',
  'linkedin.com': 'Social',
  'tiktok.com': 'Social',
  'discord.com': 'Social',

  // Entertainment
  'youtube.com': 'Entertainment',
  'netflix.com': 'Entertainment',
  'twitch.tv': 'Entertainment',
  'spotify.com': 'Entertainment',
  'disneyplus.com': 'Entertainment',
  'primevideo.com': 'Entertainment'
};

export const DEFAULT_BLOCKLIST = [
  'twitter.com',
  'x.com',
  'facebook.com',
  'instagram.com',
  'reddit.com',
  'tiktok.com',
  'netflix.com',
  'twitch.tv'
];
