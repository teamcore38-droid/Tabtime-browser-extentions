/**
 * Tab Time - Popup Logic
 * Renders real-time today metrics, Chart.js Donut, and Focus Mode controls.
 */

import { TabTimeStorage } from './storage.js';

const storage = new TabTimeStorage();
let categoryChart = null;

// Category Color Scheme
const CATEGORY_COLORS = {
  Productive: '#2E7D32',
  Educational: '#1565C0',
  Social: '#E65100',
  Entertainment: '#C2185B',
  Neutral: '#607D8B'
};

document.addEventListener('DOMContentLoaded', async () => {
  setupNavigation();
  setupFocusControls();
  await loadCurrentStatus();
  await loadTodayAnalytics();
  
  // Refresh live counters every 2 seconds while popup is open
  setInterval(async () => {
    await loadCurrentStatus();
  }, 2000);
});

function setupNavigation() {
  document.getElementById('open-dashboard-btn').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
  });

  document.getElementById('view-dashboard-link').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
  });

  document.getElementById('open-settings-btn').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('settings.html') });
  });
}

// Fetch and display active tab information
async function loadCurrentStatus() {
  try {
    const response = await chrome.runtime.sendMessage({ action: 'GET_ACTIVE_STATUS' });
    const domainEl = document.getElementById('current-domain');
    const badgeEl = document.getElementById('current-category-badge');

    if (response && response.currentDomain) {
      domainEl.textContent = response.currentDomain;
      const cat = response.currentCategory || 'Neutral';
      badgeEl.textContent = cat;
      badgeEl.className = `badge badge-${cat.toLowerCase()}`;
    } else {
      domainEl.textContent = 'Browser System Tab';
      badgeEl.textContent = 'Idle';
      badgeEl.className = 'badge badge-neutral';
    }
  } catch (e) {
    // Service worker might be waking up
  }
}

// Compute and render today's metrics and Donut chart
async function loadTodayAnalytics() {
  const todayStr = new Date().toISOString().split('T')[0];
  const sessions = await storage.getSessionsByDate(todayStr);

  const categoryTotals = {
    Productive: 0,
    Educational: 0,
    Social: 0,
    Entertainment: 0,
    Neutral: 0
  };

  let totalSeconds = 0;

  sessions.forEach(s => {
    const cat = s.category || 'Neutral';
    if (categoryTotals[cat] !== undefined) {
      categoryTotals[cat] += s.duration;
    } else {
      categoryTotals.Neutral += s.duration;
    }
    totalSeconds += s.duration;
  });

  // Calculate Productivity Score: (Productive + Educational + 0.5 * Neutral) / Total * 100
  let prodScore = 0;
  if (totalSeconds > 0) {
    const weightedScore = categoryTotals.Productive + categoryTotals.Educational + (0.5 * categoryTotals.Neutral);
    prodScore = Math.round((weightedScore / totalSeconds) * 100);
  }

  // Update UI Elements
  document.getElementById('today-time').textContent = formatDuration(totalSeconds);
  const scoreEl = document.getElementById('today-score');
  scoreEl.textContent = `${prodScore}%`;

  if (prodScore >= 70) {
    scoreEl.className = 'metric-value text-productive';
  } else if (prodScore >= 45) {
    scoreEl.className = 'metric-value';
    scoreEl.style.color = '#FB8C00';
  } else {
    scoreEl.className = 'metric-value';
    scoreEl.style.color = '#D32F2F';
  }

  renderDonutChart(categoryTotals);
}

function formatDuration(totalSec) {
  const hours = Math.floor(totalSec / 3600);
  const minutes = Math.floor((totalSec % 3600) / 60);
  if (hours > 0) {
    return `${hours}h ${minutes}m`;
  }
  return `${minutes}m`;
}

function renderDonutChart(categoryTotals) {
  const ctx = document.getElementById('todayCategoryChart').getContext('2d');
  
  const labels = Object.keys(categoryTotals);
  const data = Object.values(categoryTotals).map(s => Math.round(s / 60)); // in minutes
  const totalMins = data.reduce((a, b) => a + b, 0);

  // If zero data logged today yet, show placeholder
  const displayData = totalMins === 0 ? [1] : data;
  const displayColors = totalMins === 0 ? ['#E0E4EC'] : labels.map(l => CATEGORY_COLORS[l]);
  const displayLabels = totalMins === 0 ? ['No Activity Yet'] : labels;

  if (categoryChart) {
    categoryChart.destroy();
  }

  categoryChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: displayLabels,
      datasets: [{
        data: displayData,
        backgroundColor: displayColors,
        borderWidth: 2,
        borderColor: '#FFFFFF'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '70%',
      plugins: {
        legend: {
          position: 'right',
          labels: {
            boxWidth: 10,
            font: { size: 9.5 }
          }
        },
        tooltip: {
          callbacks: {
            label: (ctx) => {
              if (totalMins === 0) return 'No browsing recorded today';
              const val = ctx.raw;
              const pct = totalMins > 0 ? Math.round((val / totalMins) * 100) : 0;
              return ` ${ctx.label}: ${val} mins (${pct}%)`;
            }
          }
        }
      }
    }
  });
}

// Focus Mode Button & Timer Logic
function setupFocusControls() {
  const toggleBtn = document.getElementById('toggle-focus-btn');
  const statusBadge = document.getElementById('focus-status-badge');
  const countdownEl = document.getElementById('focus-countdown');

  let countdownInterval = null;

  async function updateFocusUI() {
    const { focusState } = await chrome.storage.local.get('focusState');
    if (focusState && focusState.active && focusState.endTime > Date.now()) {
      toggleBtn.textContent = 'Stop Focus Session';
      toggleBtn.className = 'btn btn-danger';
      statusBadge.textContent = 'Active';
      statusBadge.className = 'badge badge-active';
      countdownEl.classList.remove('hidden');

      if (countdownInterval) clearInterval(countdownInterval);
      countdownInterval = setInterval(() => {
        const remaining = Math.max(0, Math.round((focusState.endTime - Date.now()) / 1000));
        if (remaining <= 0) {
          clearInterval(countdownInterval);
          updateFocusUI();
        } else {
          const mins = Math.floor(remaining / 60);
          const secs = remaining % 60;
          countdownEl.textContent = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        }
      }, 1000);
    } else {
      toggleBtn.textContent = 'Start 25m Focus Session';
      toggleBtn.className = 'btn btn-primary';
      statusBadge.textContent = 'Ready';
      statusBadge.className = 'badge badge-idle';
      countdownEl.classList.add('hidden');
      if (countdownInterval) clearInterval(countdownInterval);
    }
  }

  updateFocusUI();

  toggleBtn.addEventListener('click', async () => {
    const { focusState } = await chrome.storage.local.get('focusState');
    if (focusState && focusState.active) {
      await chrome.runtime.sendMessage({ action: 'STOP_FOCUS_MODE' });
    } else {
      await chrome.runtime.sendMessage({ action: 'START_FOCUS_MODE', durationMinutes: 25 });
    }
    await updateFocusUI();
  });
}
