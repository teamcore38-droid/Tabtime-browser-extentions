/**
 * Tab Time - Background Service Worker (Manifest V3)
 * Handles real-time active tab tracking, idle state debouncing,
 * dynamic domain categorization, and Focus Mode network redirection.
 */

import { TabTimeStorage, DEFAULT_CATEGORY_RULES, DEFAULT_BLOCKLIST } from './storage.js';

const storage = new TabTimeStorage();

let activeSession = {
  domain: null,
  category: 'Neutral',
  startTime: null,
  tabId: null,
  windowId: null,
  isIdle: false
};

// Initialize Settings & Rules on Install
chrome.runtime.onInstalled.addListener(async () => {
  console.log('[TabTime] Extension installed / updated.');
  const existing = await chrome.storage.local.get(['categoryRules', 'focusBlocklist', 'focusState']);
  
  if (!existing.categoryRules) {
    await chrome.storage.local.set({ categoryRules: DEFAULT_CATEGORY_RULES });
  }
  if (!existing.focusBlocklist) {
    await chrome.storage.local.set({ focusBlocklist: DEFAULT_BLOCKLIST });
  }
  if (!existing.focusState) {
    await chrome.storage.local.set({
      focusState: {
        active: false,
        endTime: null,
        durationMinutes: 25
      }
    });
  }

  // Restore any pending open session checkpoint
  await restoreSessionCheckpoint();
});

// Helper: Normalize URL to Root Domain
function extractDomain(url) {
  try {
    if (!url || url.startsWith('chrome://') || url.startsWith('edge://') || url.startsWith('about:')) {
      return null;
    }
    const parsed = new URL(url);
    let host = parsed.hostname.toLowerCase();
    if (host.startsWith('www.')) {
      host = host.substring(4);
    }
    return host;
  } catch (e) {
    return null;
  }
}

// Categorize Domain using Custom Rules
async function getCategoryForDomain(domain) {
  if (!domain) return 'Neutral';
  const { categoryRules = DEFAULT_CATEGORY_RULES } = await chrome.storage.local.get('categoryRules');
  if (categoryRules[domain]) return categoryRules[domain];

  // Subdomain fallback (e.g. docs.google.com -> google.com)
  const parts = domain.split('.');
  if (parts.length > 2) {
    const parent = parts.slice(-2).join('.');
    if (categoryRules[parent]) return categoryRules[parent];
  }

  return 'Neutral';
}

// Flush and Save Active Session to IndexedDB & Chrome Storage
async function closeActiveSession() {
  if (!activeSession.domain || !activeSession.startTime || activeSession.isIdle) {
    return;
  }

  const now = Date.now();
  const durationSeconds = Math.round((now - activeSession.startTime) / 1000);

  // Ignore transient hops under 1 second
  if (durationSeconds >= 1) {
    const todayStr = new Date().toISOString().split('T')[0];
    const record = {
      domain: activeSession.domain,
      category: activeSession.category,
      duration: durationSeconds,
      startTime: activeSession.startTime,
      endTime: now,
      date: todayStr
    };

    try {
      await storage.recordSession(record);
      // Update running daily memory cache in chrome.storage.local for instantaneous popup queries
      await updateDailyAggregates(record);
    } catch (err) {
      console.error('[TabTime] Failed to write session to storage:', err);
    }
  }

  activeSession.startTime = null;
  await chrome.storage.local.remove('activeSessionCheckpoint');
}

// Atomic Checkpoint to prevent MV3 Service Worker sleep data loss
async function saveSessionCheckpoint() {
  if (activeSession.domain && activeSession.startTime && !activeSession.isIdle) {
    await chrome.storage.local.set({
      activeSessionCheckpoint: {
        domain: activeSession.domain,
        category: activeSession.category,
        startTime: activeSession.startTime,
        tabId: activeSession.tabId,
        windowId: activeSession.windowId
      }
    });
  }
}

async function restoreSessionCheckpoint() {
  const { activeSessionCheckpoint } = await chrome.storage.local.get('activeSessionCheckpoint');
  if (activeSessionCheckpoint) {
    const now = Date.now();
    const durationSeconds = Math.round((now - activeSessionCheckpoint.startTime) / 1000);
    if (durationSeconds >= 1 && durationSeconds < 86400) {
      const todayStr = new Date(activeSessionCheckpoint.startTime).toISOString().split('T')[0];
      await storage.recordSession({
        domain: activeSessionCheckpoint.domain,
        category: activeSessionCheckpoint.category,
        duration: durationSeconds,
        startTime: activeSessionCheckpoint.startTime,
        endTime: now,
        date: todayStr
      });
    }
    await chrome.storage.local.remove('activeSessionCheckpoint');
  }
}

// Update Daily Aggregate Cache
async function updateDailyAggregates(record) {
  const { todayTotals = {} } = await chrome.storage.local.get('todayTotals');
  const cat = record.category || 'Neutral';
  const dom = record.domain;

  if (!todayTotals.categories) todayTotals.categories = {};
  if (!todayTotals.domains) todayTotals.domains = {};

  todayTotals.categories[cat] = (todayTotals.categories[cat] || 0) + record.duration;
  todayTotals.domains[dom] = (todayTotals.domains[dom] || 0) + record.duration;
  todayTotals.totalDuration = (todayTotals.totalDuration || 0) + record.duration;
  todayTotals.date = record.date;

  await chrome.storage.local.set({ todayTotals });
}

// Start New Active Tab Tracking
async function startTrackingTab(tabId, windowId) {
  if (!tabId || tabId === chrome.tabs.TAB_ID_NONE) return;

  try {
    const tab = await chrome.tabs.get(tabId);
    if (!tab || !tab.url) return;

    const domain = extractDomain(tab.url);
    if (!domain) {
      await closeActiveSession();
      activeSession.domain = null;
      return;
    }

    // If same domain is still active, don't restart clock
    if (activeSession.domain === domain && activeSession.tabId === tabId && !activeSession.isIdle) {
      return;
    }

    await closeActiveSession();

    const category = await getCategoryForDomain(domain);
    activeSession = {
      domain,
      category,
      startTime: Date.now(),
      tabId,
      windowId,
      isIdle: false
    };

    await saveSessionCheckpoint();
  } catch (err) {
    // Tab might have been closed immediately
  }
}

// --- EVENT LISTENERS ---

// 1. Tab Activated (Tab Switch)
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  await startTrackingTab(activeInfo.tabId, activeInfo.windowId);
});

// 2. Tab Updated (URL change in current tab)
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.url && tab.active) {
    await startTrackingTab(tabId, tab.windowId);
  }
});

// 3. Window Focus Changed (User switches application or window)
chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    // Browser lost focus
    await closeActiveSession();
    activeSession.isIdle = true;
  } else {
    // Browser regained focus
    const [activeTab] = await chrome.tabs.query({ active: true, windowId });
    if (activeTab) {
      await startTrackingTab(activeTab.id, windowId);
    }
  }
});

// 4. Idle Detection (60-second calibrated threshold)
chrome.idle.setDetectionInterval(60);
chrome.idle.onStateChanged.addListener(async (newState) => {
  if (newState === 'idle' || newState === 'locked') {
    await closeActiveSession();
    activeSession.isIdle = true;
  } else if (newState === 'active') {
    activeSession.isIdle = false;
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (activeTab) {
      await startTrackingTab(activeTab.id, activeTab.windowId);
    }
  }
});

// 5. Message Dispatcher for UI Actions (Focus Mode toggle, queries)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'START_FOCUS_MODE') {
    enableFocusMode(message.durationMinutes || 25).then(() => {
      sendResponse({ success: true });
    });
    return true;
  } else if (message.action === 'STOP_FOCUS_MODE') {
    disableFocusMode().then(() => {
      sendResponse({ success: true });
    });
    return true;
  } else if (message.action === 'GET_ACTIVE_STATUS') {
    sendResponse({
      activeSession,
      currentDomain: activeSession.domain,
      currentCategory: activeSession.category,
      elapsedSeconds: activeSession.startTime ? Math.round((Date.now() - activeSession.startTime) / 1000) : 0
    });
    return false;
  }
});

// --- FOCUS MODE (declarativeNetRequest Dynamic Rules Engine) ---

async function enableFocusMode(durationMinutes) {
  const { focusBlocklist = DEFAULT_BLOCKLIST } = await chrome.storage.local.get('focusBlocklist');
  const blockedPageUrl = chrome.runtime.getURL('blocked.html');

  // Build declarativeNetRequest dynamic redirect rules
  const rules = focusBlocklist.map((domain, index) => ({
    id: index + 1,
    priority: 1,
    action: {
      type: 'redirect',
      redirect: { url: `${blockedPageUrl}?blocked=${encodeURIComponent(domain)}` }
    },
    condition: {
      urlFilter: `||${domain}`,
      resourceTypes: ['main_frame']
    }
  }));

  // Update dynamic rules
  const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existingRules.map(r => r.id);

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds,
    addRules: rules
  });

  const endTime = Date.now() + durationMinutes * 60 * 1000;
  await chrome.storage.local.set({
    focusState: {
      active: true,
      endTime,
      durationMinutes
    }
  });

  // Set Chrome alarm for auto session conclusion
  chrome.alarms.create('FOCUS_SESSION_END', { when: endTime });
  console.log(`[TabTime] Focus Mode activated for ${durationMinutes} mins.`);
}

async function disableFocusMode() {
  const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existingRules.map(r => r.id);

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds,
    addRules: []
  });

  await chrome.storage.local.set({
    focusState: {
      active: false,
      endTime: null,
      durationMinutes: 25
    }
  });

  chrome.alarms.clear('FOCUS_SESSION_END');
  console.log('[TabTime] Focus Mode ended. Rules purged.');
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'FOCUS_SESSION_END') {
    await disableFocusMode();
  }
});
