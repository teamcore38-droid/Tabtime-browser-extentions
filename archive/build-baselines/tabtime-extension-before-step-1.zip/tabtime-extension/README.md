# Tab Time — Browser Extension Code Implementation & Guide

**Tab Time** is a privacy-preserving browser extension engineered under the **Manifest V3** specification for Chromium (Google Chrome, Edge, Brave) and Gecko (Mozilla Firefox) browsers.

---

## 📂 Codebase Directory Structure

```
tabtime-extension/
├── manifest.json         # Manifest V3 Extension Configuration & Permissions
├── background.js        # Background Service Worker (Real-Time Tracking & declarativeNetRequest Engine)
├── storage.js           # 100% Local IndexedDB & chrome.storage.local Data Layer
│
├── popup.html           # Toolbar Popup Interface (Matches Figure A.1)
├── popup.css            # Modern Glassmorphism Styling for Popup
├── popup.js             # Real-Time Popup Timer, Donut Chart & Focus Mode Quick Toggle
│
├── dashboard.html       # Full Interactive Analytics Dashboard (Matches Figure A.2 & Figure 7.1)
├── dashboard.css        # Multi-Column Dashboard Layout & Modern CSS Design System
├── dashboard.js         # Weekly Stacked Bar Chart, Category Donut & Top Sites Table
│
├── settings.html        # Domain Rules & Focus Blocklist Interface (Matches Figure A.3)
├── settings.css         # Clean Card Layout & Table Styling for Settings
├── settings.js          # Custom Category Mappings, Blocklist CRUD & Data Export/Purge
│
├── blocked.html         # Focus Mode Redirect Holding Page (Mindful Pause)
├── blocked.css          # Deep Violet Gradient & Focus Timer Badge
├── blocked.js           # Live Countdown Timer & Mindful Work Redirection
│
├── libs/
│   └── chart.umd.js     # Offline Standalone Chart.js Bundle (Zero CDN / Offline MV3 Compliant)
└── icons/
    ├── icon16.png       # 16x16 Toolbar Favicon
    ├── icon32.png       # 32x32 Action Icon
    ├── icon48.png       # 48x48 Extension Management Icon
    └── icon128.png      # 128x128 High-Resolution Chrome Web Store Icon
```

---

## 🚀 How to Load & Run the Extension in Google Chrome (In 3 Clicks):

1. Open **Google Chrome** (or Edge / Brave).
2. In the address bar, navigate to: `chrome://extensions`
3. In the top-right corner, switch ON **"Developer mode"**.
4. In the top-left corner, click **"Load unpacked"**.
5. Select the folder:  
   👉 `d:\My Project\Browser Extenstion project\tabtime-extension`
6. Click **Select Folder** — Tab Time will instantly appear in your browser toolbar with the stopwatch icon!

---

## 📸 Screenshots You Can Capture for the Report:

1. **Code Screenshots (VS Code / IDE View):**
   - Open `background.js` or `storage.js` in VS Code to capture clean, professional code snippets.
   - Open `manifest.json` to capture the Manifest V3 architecture.
2. **UI Screenshots (Live Browser View):**
   - **Toolbar Popup:** Click the Tab Time stopwatch icon in your browser toolbar.
   - **Full Analytics Dashboard:** Right-click the extension icon $\rightarrow$ Open Dashboard, or open `chrome-extension://<id>/dashboard.html`.
   - **Settings Page:** Open `chrome-extension://<id>/settings.html`.
   - **Focus Holding Page:** Open `chrome-extension://<id>/blocked.html?blocked=twitter.com`.
